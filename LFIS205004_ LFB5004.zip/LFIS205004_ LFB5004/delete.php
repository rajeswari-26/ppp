<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Selecting Values</title>
        <!-- styling background -->
            <style>
                body
                {
                    background-color:rgb(56, 36, 36);
                }
                .bg 
                {
                    background-color: rgb(56, 36, 36);
                    height: 1400px;
                    background-position: center;
                    background-repeat: no-repeat;
                    position: relative;
                }
                .container
                {
                    background-color: white;
                    width: 1200px;
                    height:1300px;
                    margin-top: 50px;
                    margin-left: 65px;
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    background-color: rgb(196, 193, 28);
                    padding-top: 30px;
                    
                } 
                .heading
                {
                    width : 1095px;
                    height:100px;
                    margin-left: 50px;
                    background-color: rgb(122, 173, 231);
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    text-align: center;
                    padding-top: 20px;   
                }
                .content
                {
                    padding-top:50px;
                    padding-right:10px;
                    padding-left:10px;
                    padding-bottom:50px;
                    text-align:center;
                    font-family: 'Times New Roman', Times, serif;
                    font-weight: bold;
                    font-size:20px;
                }
                h1
                {
                    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
                    color: rgb(94, 35, 17);
                    font-weight: bolder;
                }    
                

             </style> 
    </head>

    <body>
        <div class="bg">
            <div class="container">
                <div class="heading">
                    <h1> ORDER DATABASE</h1>
                </div>
                <div  class = "content">
				
                <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "movie";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error)
                    {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    // deleting a row in actor table
                    if(isset($_POST['Delete1'])) 
                    {    
                        $sales_id1 = $_POST['sales_id1'];
                      
                    // sql query to delete a row
                    $sql = mysqli_query($conn,"DELETE FROM SALESMAN where sales_id=$sales_id1");
            

                    if ($sql===TRUE)
                    {
                        echo "<font color='brown'>Record is Deleted successfully<br/>";
                        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";

                    }
                    else
                    {
                    echo "Enter the    custom-ID!!!!!!!!!!";
                    }
                    }
                   
                    // deleting  a record in  CUSTOMER table
                    if(isset($_POST['Delete2'])) 
                    {    
                        $   custom_id1 = $_POST['   custom_id1'];
                       
                     
                    // sql query to delete a record
                        $sql1 = "DELETE FROM    custom WHERE dir_id=$   custom_id1";

                        if(mysqli_query($conn, $sql1)){
                            echo "<font color='brown'>Record is Deleted successfully<br/>";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";

                            
                        } else{
                            echo "Enter the   custom-ID!!!!!!!!!!";
                        }
                    }
                
                    $conn->close();
                
                    ?>

                                
                </div>
                


            </div>
        
        </div>
</body>
</html>