<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Selecting Values</title>
        <!-- styling background -->
            <style>
                body
                {
                    background-color:rgb(56, 36, 36);
                }
                .bg 
                {
                    background-color: rgb(56, 36, 36);
                    height: 1400px;
                    background-position: center;
                    background-repeat: no-repeat;
                    position: relative;
                }
                .container
                {
                    background-color: white;
                    width: 1200px;
                    height:1300px;
                    margin-top: 50px;
                    margin-left: 65px;
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    background-color: rgb(196, 193, 28);
                    padding-top: 30px;
                    
                } 
                .heading
                {
                    width : 1095px;
                    height:100px;
                    margin-left: 50px;
                    background-color: rgb(122, 173, 231);
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    text-align: center;
                    padding-top: 20px;   
                }
                .content
                {
                    padding-top:50px;
                    padding-right:10px;
                    padding-left:10px;
                    padding-bottom:50px;
                    text-align:center;
                    font-family: 'Times New Roman', Times, serif;
                    font-weight: bold;
                    font-size:20px;
                }
                h1
                {
                    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
                    color: rgb(94, 35, 17);
                    font-weight: bolder;
                }  
                /* styling table   */
                table, td, th 
                {  
                    border: 1px solid black;
                    text-align: center;
                }

                table 
                {
                    width: 100%;
                }
                th
                {
                    background-color :rgb(122, 173, 231); 
                }

                tr:hover 
                {
                    background-color:#f5f5f5;
                }

             </style> 
			
    </head>

    <body>
        <div class="bg">
            <div class="container">
                <div class="heading">
                    <h1> ORDER DATABASE</h1>
                </div>
                <div  class = "content">
                    <?php

                        $databaseHost = 'localhost';
                        $databaseName = 'movie';
                        $databaseUsername = 'root';
                        $databasePassword = '';
                        
                        $conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
                        // Check connection
                        if (!$conn) 
                        {
                            die("Connection failed: " . mysqli_connect_error());
                        }
                        //echo"Connect to database";
                        $display= $_POST['disp'];
                       
                        // displaying value from each table
                        if($display=="all") 
                        {     

                            $sql = "select a.sales_id,a.sales_name,a.sales_gender,b.custom_id,b.custom_name,b.custom_phone,c.custom_id,c. ord_title,c. ord_year,c. ord_lang,d.role,e.rev_stars from actor a , 
                            AND b. ord_id=c. ord_id AND c. ord_id=d.mov_id AND c.custom_id=e.custom_ID ";
                            $result = $conn->query($sql);
                           
                            if ($result->num_rows > 0)
                            {
                                echo "<h1 style='color:blue; font-family:courier; font-size:30px;'> The Movie-Database Details are Listed Below</h1>";
                                echo "<div ><table><tr>
                                <th> sales-Id</th>
                                <th> sales-Name</th>
                                <th> sales-Gender </th>
                                <th>   custom-Id </th>
                                <th>   custom-Name </th>
                                <th>   custom-Phone </th>
                                <th>   ord-Id</th>
                                <th>   ord-Title </th>
                                <th>   ord-Year </th>
                             
                                </tr>";
                                    // output data of each row
                                 while($row = $result->fetch_assoc()) 
                                 {
                                     echo "<tr>

                                    <td>" . $row["sales_id"]. "</td>
                                    <td>" . $row["sales_name"]. "</td>
                                    <td>" . $row["sales_gender"]. "</td>
                                    <td>" . $row["custom_id"]. "</td>
                                    <td>" . $row["custom_name"]. "</td>
                                    <td>" . $row["custom_phone"]. "</td>
                                    <td>" . $row["ord_id"]. "</td>
                                    <td>" . $row["ord_title"]. "</td>
                                     <td>" . $row["ord_year"]. "</td>
                                         
                                    </tr>";
                                  }
                                  echo "</table></div>";
                                  echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                            } 
                            else 
                            {
                                echo "There is no information Found!!";
                                echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                            }
                        }
                        // displaying only SALESMAN table
                        else if($display=="Act") 
                        {    

                            $sql = "SELECT sales_id, sales_name, sales_gender  FROM SALESMAN ;";
                            $result = $conn->query($sql);
                           
                            if ($result->num_rows > 0)
                            {
                                echo "<h1 style='color:blue; font-family:courier; font-size:30px;'> The SALESMAN Details are Listed Below</h1>";
                                echo "<div ><table><tr>
                                <th>sales-Id</th>
                                <th>sales-Name</th>
                                <th>sales-Gender </th>
                                </tr>";
                                
                                while($row = $result->fetch_assoc()) 
                                {
                                    echo "<tr>
                                    <td>" . $row["sales_id"]. "</td>
                                    <td>" . $row["sales_name"]. "</td>
                                    <td>" . $row["sales_gender"]. "</td>
                                    </tr>";
                                }
                                echo "</table></div>";
                                echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                            }
                            else 
                            {
                                echo "There is no information Found!!";
                                echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                            }
                        }
                        // displaying only CUSTOMER table
                        else if($display=="Dir") 
                        {    

                            $sql = "select   custom_id,  custom_name,  custom_phone from CUSTOMER";
                            $result = $conn->query($sql);
                     
                            if ($result->num_rows > 0)
                            {
                                echo "<h1 style='color:blue; font-family:courier; font-size:30px;'> The Director Details are Listed Below</h1>";
                            if ($result->num_rows > 0)
                                echo "<div ><table><tr>
                            
                                <th>   custom-Id </th>
                                <th>   custom-Name </th>
                                <th>   custom-Phone </th>
                            
                                </tr>";
                                // output data of each row
                                while($row = $result->fetch_assoc()) 
                                {
                                    echo "<tr>

                                    
                                    <td>" . $row["custom_id"]. "</td>
                                    <td>" . $row["custom_name"]. "</td>
                                    <td>" . $row["custom_phone"]. "</td>
                                
                                    
                                    
                                    </tr>";
                                }
                                echo "</table></div>";

                                echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                             } 
                             else 
                             {
                                 echo "There is no information Found!!";
                                 echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                             }
                    }
                    // diaplaying only ORDER table
                        else if($display=="ord") 
                        {    

                            $sql = "select mov_id,ORDER_title,ORDER_year,ORDER_lang,ORDER_id from movies";
                            $result = $conn->query($sql);
                           
                            if ($result->num_rows > 0)
                            {
                                echo "<h1 style='color:blue; font-family:courier; font-size:30px;'> The Movies Details are Listed Below</h1>";
                            echo "<div ><table><tr>
                            
                            <th> ord-Id</th>
                            <th> ord-Title </th>
                            <th> ord-Year </th>
                            
                        
                            </tr>";
                            // output data of each row
                            while($row = $result->fetch_assoc()) 
                            {
                                echo "<tr>

                                
                                <td>" . $row["ord_id"]. "</td>
                                <td>" . $row["ord_title"]. "</td>
                                <td>" . $row["ord_year"]. "</td>
                               
                            
                                
                                </tr>";
                            }
                            echo "</table></div>";

                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        } 
                        else 
                        {
                            echo "There is no information Found!!";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    }
                   
                            // output data of each row
                            while($row = $result->fetch_assoc()) 
                            {
                                echo "<tr>

                                <td>" . $row["sales_id"]. "</td>
                            
                                <td>" . $row["   custom_id"]. "</td>
                            
                                <td>" . $row[" ord"]. "</td>
                            
                                
                                </tr>";
                            }
                            echo "</table></div>";

                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        } 
                        else 
                        {
                            echo "There is no information Found!!";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    }
                    // displying rating table
                      else  if($display=="Rat") 
                        {    

                            $sql = "select mov_id,rev_stars from rating  ";
                            $result = $conn->query($sql);
                            
                            if ($result->num_rows > 0)
                            {
                                echo "<h1 style='color:blue; font-family:courier; font-size:30px;'> The Rating Details are Listed Below</h1>";
                            echo "<div ><table><tr>
                        
                            <th>  ORDER-Id</th>
                           
                          
                            </tr>";
                            // output data of each row
                            while($row = $result->fetch_assoc()) 
                            {
                                echo "<tr>

                            
                                <td>" . $row[" ord_id"]. "</td>
                            
                                
                                
                                </tr>";
                            }
                            echo "</table></div>";

                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        } 
                        else 
                        {
                            echo "There is no information Found!!";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    }
                        
                        
                        else 
                        {
                            echo "There is no information Found!!";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    

                        $conn->close();

                    ?> 

                                
                </div>
                


            </div>
        
        </div>
</body>
</html>