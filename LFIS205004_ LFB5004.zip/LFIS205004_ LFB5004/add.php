<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Adding details</title>
    <!-- styling background -->
    <style>

body{ 
    background-color:rgb(56, 36, 36);
}
.bg {
 
  background-color: rgb(56, 36, 36);
  height: 1400px;
  background-position: center;
  background-repeat: no-repeat;

  position: relative;
  }
  .container
  {
      background-color: white;
      width: 1200px;
      height:1300px;
      margin-top: 50px;
      margin-left: 65px;
      border-radius: 20px;
      box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
      background-color: rgb(196, 193, 28);
      padding-top: 30px;
     
  } 
  .heading
  {
      width : 1095px;
      height:100px;
      margin-left: 50px;
      background-color: rgb(122, 173, 231);
      border-radius: 20px;
      box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
      text-align: center;
      padding-top: 20px;   
  }

    .content{
      padding-top:50px;
      padding-rigth:100px;
      padding-left:30px;
      padding-bottom:50px;
      text-align:center;
      font-family: 'Times New Roman', Times, serif;
      font-weight: bold;
      font-size:20px;
  }
  h1{
      font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      color: rgb(94, 35, 17);
      font-weight: bolder;
  }

    </style>

</head>

<body>
    <div class="bg">

        <div class="container">
            <div class="heading">
                <h1> ORDER DATABASE</h1>
            </div>

<!-- content where php displays its output -->
<div  class = "content">

<?php

$databaseHost = 'localhost';
$databaseName = 'ORDER';
$databaseUsername = 'root';
$databasePassword = '';
 
$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
 //echo"Connect to database";
 if(isset($_POST['Submit'])) 
 {    
    $SALESMAN_id = $_POST['sales_id'];
	$SALESMAN_name = $_POST['sales_name'];
    $SALESMAN_gender = $_POST['sales_gender'];
    $CUSTOMER_id= $_POST['custom_id'];
	$CUSTOMER_name = $_POST['custom_name'];
	$CUSTOMER_phone = $_POST['custom_phone'];
    $ORDER_id = $_POST[' ord_id'];
	$ORDER_title = $_POST[' ord_title'];
	$ORDER_year = $_POST[' ord_year'];

  
  

        
    // checking empty fields
    if(empty($custom_id) || empty($custom_name )|| empty($custom_gender) ||empty($sales_id) ||empty($sales_name) ||empty($sales_phone) 
    ||empty($ ord_id) ||empty($ ord_title) ||empty($ ord_year))
    {                
        
        if(empty($custom_id) )
        {
            echo "<font color='brown'>custom-ID : field is empty.</font><br/>";
        }
        
        if(empty($custom_name))
         {
            echo "<font color='brown'>custom-NAME : field is empty.</font><br/>";
        }
        if(empty($custom_gender)) 
        {
            echo "<font color='brown'>custom-GENDER : field is empty.</font><br/>";
        }
        if(empty($sales_id) )
        {
            echo "<font color='brown'>sales-ID : field is empty.</font><br/>";
        }
        
        if(empty($sales_name))
         {
            echo "<font color='brown'>sales-NAME : field is empty.</font><br/>";
        }
       
	   {
        if(empty($ ord_id) )
        {
            echo "<font color='brown'>ORDER-ID : field is empty.</font><br/>";
        }
        
        if(empty($ ord_title))
         {
            echo "<font color='brown'>ORDER-TITLE : field is empty.</font><br/>";
        }
        if(empty($ ord_year)) 
        {
            echo "<font color='brown'>ORDER-YEAR : field is empty.</font><br/>";
        }
       
       
     
		
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }
else
	{ 
        // if all the fields are filled (not empty)             
        //insert data to database

         $sql = "INSERT INTO SALESMAN VALUES ($sales_id,'$sales_name','$sales_gender')";
         $sql1 = "INSERT INTO CUSTOMER VALUES ($custom_id,'$custom_name',$custom_phone)";
         $sql3= "INSERT INTO ORDER VALUES ($ ord_id,$ ord_id,)";
        
         
         
		 
         if (mysqli_query($conn, $sql) && mysqli_query($conn,$sql1) && mysqli_query($conn,$sql2) && mysqli_query($conn,$sql3) && mysqli_query($conn,$sql4) ) {
            echo "<font color='green'>Data added successfully into Movie-Database <br/>";
            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
    echo "Error: " . $sql2 . "<br>" . mysqli_error($conn);
    echo "Error: " . $sql3 . "<br>" . mysqli_error($conn);
    echo "Error: " . $sql4 . "<br>" . mysqli_error($conn);


    echo "<br><br/><a href='javascript:self.history.back();'>Go Back</a>";
  }

		
		
        
    }
}
	
?>

            </div>

        </div>
       
    </div>
</body>

</html>