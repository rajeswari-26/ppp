<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Selecting Values</title>
            <!-- styling background -->
            <style>
                body
                {
                    background-color:rgb(56, 36, 36);
                }
                .bg 
                {
                    background-color: rgb(56, 36, 36);
                    height: 1400px;
                    background-position: center;
                    background-repeat: no-repeat;
                    position: relative;
                }
                .container
                {
                    background-color: white;
                    width: 1200px;
                    height:1300px;
                    margin-top: 50px;
                    margin-left: 65px;
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    background-color: rgb(196, 193, 28);
                    padding-top: 30px;
                    
                } 
                .heading
                {
                    width : 1095px;
                    height:100px;
                    margin-left: 50px;
                    background-color: rgb(122, 173, 231);
                    border-radius: 20px;
                    box-shadow: 0 10px 30px 0 rgb(121, 132, 185);
                    text-align: center;
                    padding-top: 20px;   
                }
                .content
                {
                    padding-top:50px;
                    padding-right:10px;
                    padding-left:10px;
                    padding-bottom:50px;
                    text-align:center;
                    font-family: 'Times New Roman', Times, serif;
                    font-weight: bold;
                    font-size:20px;
                }
                h1
                {
                    font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
                    color: rgb(94, 35, 17);
                    font-weight: bolder;
                }
                /* styling table design     */
                table, td, th 
                {  
                    border: 1px solid black;
                    text-align: center;
                }

                table 
                {
                    width: 100%;
                }
                th
                {
                    background-color :rgb(122, 173, 231); 
                }

                tr:hover 
                {
                    background-color:#f5f5f5;
                }

             </style> 
    </head>

    <body>
        <div class="bg">
            <div class="container">
                <div class="heading">
                    <h1> ORDER DATABASE</h1>
                </div>
				 
                <div  class = "content">
                <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "ORDER";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    // serching for a details from ORDER table
                    if(isset($_POST['Search'])) 
                    {    
                        $mov_id1 = $_POST['ord_id1'];
                        $sql  = "Select a.ord_id,a.ord_title,a.ord_year,a. CUSTOMER_id , a.SALESMAN_id=b. CUSTOMER_id =$ord_id1;";
                  
                        $result = $conn->query($sql);
                  
                        if ($result->num_rows > 0) 
                        {
                            echo "<h1 style='color:blue; font-family:courier; font-size:30px;'>Searched result is as shown below </h1>";
                        if ($result->num_rows > 0) 
                            echo "<div ><table><tr>
                            
                            <th>  ord-Id</th>
                            <th>  ord-Title </th>
                            <th>  ord-Year </th>
                            <th>  ord-Lang </th>
                            <th>  ord-Rating </th>
                           
                            </tr>";
                                // output data of each row
                            while($row = $result->fetch_assoc()) 
                            {
                                echo "<tr>
                            
                               
                                <td>" . $row[" ord_id"]. "</td>
                                <td>" . $row[" ord_title"]. "</td>
                                <td>" . $row[" ord_year"]. "</td>
                                   
                                </tr>";
                            }
                            echo "</table></div>";
                            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        } 
                        else
                        {
                        echo "Pls Enter the  ord-Id !!!";
                        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    }
                
                        else
                        {
                        echo "There is no Students information Found!!";
                        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
                        }
                    


                    
                    $conn->close();
                    ?>
                                
                </div>
                


            </div>
        
        </div>
</body>
</html>